{-# LANGUAGE LambdaCase, BlockArguments, ViewPatterns, TupleSections, StandaloneDeriving, DerivingVia, StrictData #-}
module Main where

import Prelude hiding (lookup)
import Control.Applicative hiding (many, some)
import Control.Monad
import Data.Char
import Data.Void
import System.Environment ()
import System.Exit
import Text.Megaparsec
import Text.Printf

import qualified Text.Megaparsec.Char       as C
import qualified Text.Megaparsec.Char.Lexer as L

ex0 = main' "nf" $ unlines [
  "let id : ∀ l. (A : U l) -> A -> A",
  "  = Λ l. \\A x. x;",
  "",
  "let const : ∀ l. ∀ k. (A : U l) -> (B : U k) -> A -> B -> A",
  "  = Λ l. Λ k. \\A B x y. x;",
  "",
  "let Nat : ∀ l. U l + 1 = Λ l. (N : U l) -> (N -> N) -> N -> N ;",
  "let zero : ∀ l. Nat {l} = Λ l. \\N s z. z;",
  "let succ : ∀ l. Nat {l} -> Nat {l} = Λ l. \\n N s z. s (n N s z);",
  "let two : ∀ l. Nat {l} = Λ l. succ {l} (succ {l} (zero {l}));",
  "let add : ∀ l. Nat {l} -> Nat {l} -> Nat {l} = Λ l. \\n m N s z. n N s (m N s z);",
  "let four : ∀ l. Nat {l} = Λ l. add {l} (two {l}) (two {l});",
  "",
  "let Eq : ∀ l. (A : U l) -> A -> A -> U l + 1",
  "  = Λ l. \\A x y. (P : A -> U l) -> P x -> P y ;",
  "let refl : ∀ l. (A : U l) -> (x : A) -> Eq {l} A x x",
  "  = Λ l. \\A x P px. px ;",
  "",
  "let sym : ∀ l. (A : U l) -> (x y : A) -> Eq {l} A x y -> Eq {l} A y x",
  "  = Λ l. \\A x y p Q. p (\\z. Q z -> Q x) (\\qx. qx) ;",
  "",
  "let UEq : ∀ l. Eq {l + 2} (U l + 1) (U l) (U l)",
  "  = Λ l. refl {l + 2} (U l + 1) (U l) ;",
  "",
  "let Lift1 : ∀ l. U l -> U l + 1 = Λ l. \\A. A;",
  "let doubleLift : ∀ l. (A : U l) -> U l + 2 = Λ l. \\A. Lift1 {l + 1} (Lift1 {l} A);",
  "",
  "four {0}"
  ]


-- syntax
--------------------------------------------------------------------------------

-- De Bruijn index.
newtype Ix  = Ix  Int deriving (Eq, Show, Num) via Int

-- De Bruijn level.
newtype Lvl = Lvl Int deriving (Eq, Show, Num) via Int

type Name = String

data RawSize = RSzVar Name | RSz Int | RSucc RawSize deriving Show
data Size = LVar Ix | Zero | Succ Size 

instance Eq Size where
  Zero == Zero = True
  LVar x == LVar y = x == y
  Succ s1 == Succ s2 = s1 == s2
  _ == _ = False

-- Preorder structure on levels
instance Ord Size where
  Zero <= _ = True
  Succ s1 <= Succ s2 = s1 <= s2
  LVar x <= LVar y = x == y
  LVar x <= Succ s2 = LVar x <= s2
  _ <= _ = False
  
  Zero < Succ _ = True
  Succ s1 < Succ s2 = s1 < s2
  LVar x < Succ s2 = LVar x <= s2
  _ < _ = False

instance Show Size where
  show (LVar i) = show i
  show Zero = "0"
  show (Succ s) = show s ++ " + 1"

data Raw
  = RVar Name              -- x
  | RLam Name Raw          -- \x. t
  | RApp Raw Raw           -- t u
  | RU RawSize             -- U i
  | RPi Name Raw Raw       -- (x : A) -> B
  | RLPi Name Raw          -- ∀ l. A
  | RLAbs Name Raw         -- Λ l. t
  | RLApp Raw RawSize      -- t {s}
  | RLet Name Raw Raw Raw  -- let x : A = t in u
  | RSrcPos SourcePos Raw  -- source position for error reporting
  deriving Show

-- core syntax
------------------------------------------------------------

data Tp
  = Pi Name ~Tp Tp
    | U Size 
    | Decode Size Tm
    | LPi Name Tp

data Tm
  = Var Ix
  | App Tm ~Tm
  | Code Size Tp
  | Lam Name Tm
  | Let Name Tp Tm Tm
  | LAbs Name Tm
  | LApp Tm Size

-- values
------------------------------------------------------------

data VSize = VLVar Lvl | VZero | VSucc VSize

instance Eq VSize where
  VZero == VZero = True
  VLVar x == VLVar y = x == y
  VSucc s1 == VSucc s2 = s1 == s2
  _ == _ = False

-- Preorder structure on semantic levels
instance Ord VSize where
  VZero <= _ = True
  VSucc s1 <= VSucc s2 = s1 <= s2
  VLVar x <= VLVar y = x == y
  VLVar x <= VSucc s2 = VLVar x <= s2
  _ <= _ = False
  
  VZero < VSucc _ = True
  VSucc s1 < VSucc s2 = s1 < s2
  VLVar x < VSucc s2 = VLVar x <= s2
  _ < _ = False

instance Show VSize where
  show (VLVar i) = show i
  show VZero = "0"
  show (VSucc s) = show s ++ " + 1"

data VEnvVal = VETm VTm | VESize VSize
type Env = [VEnvVal]

data VTp
  = VPi Name ~VTp (VTm -> VTp)
    | VU VSize 
    | VDecode VSize VTm
    | VLPi Name (VSize -> VTp)

data VTm
  = VVar Lvl
  | VApp VTm ~VTm
  | VCode VSize VTp
  | VLam Name (VTm -> VTm)
  | VLAbs Name (VSize -> VTm)
  | VLApp VTm VSize

--------------------------------------------------------------------------------

evalSize :: Env -> Size -> VSize
evalSize env = \case
  LVar (Ix x) -> case env !! x of
    VESize s -> s
    _ -> error "Evaluation error: Expected a level variable in environment"
  Zero -> VZero 
  Succ s -> VSucc (evalSize env s)

evalTm :: Env -> Tm -> VTm
evalTm env = \case
  Var (Ix x) -> case env !! x of
    VETm t -> t
    _ -> error "Evaluation error: Expected a term variable in environment"
  App t u -> case (evalTm env t, evalTm env u) of
    (VLam _ t, u) -> t u
    (t       , u) -> VApp t u
  Lam x t -> VLam x \v -> evalTm (VETm v:env) t
  Let x _ t u -> evalTm (VETm (evalTm env t) : env) u
  LAbs x t -> VLAbs x \i -> evalTm (VESize i : env) t
  LApp t s -> case evalTm env t of
    VLAbs _ f -> f (evalSize env s)
    f -> VLApp f (evalSize env s)

  -- Coding
  Code i a -> VCode (evalSize env i) (evalTp env a)

evalTp :: Env -> Tp -> VTp
evalTp env = \case
  Pi x a b -> VPi x (evalTp env a) \v -> evalTp (VETm v:env) b
  U i -> VU (evalSize env i)
  LPi x t -> VLPi x \i -> evalTp (VESize i : env) t

  -- Decoding
  Decode i t -> case evalTm env t of
    VCode j a | evalSize env i == j -> a 
    v -> VDecode (evalSize env i) v


lvl2Ix :: Lvl -> Lvl -> Ix
lvl2Ix (Lvl l) (Lvl x) = Ix (l - x - 1)

quoteSize :: Lvl -> VSize -> Size
quoteSize l = \case
  VLVar x -> LVar (lvl2Ix l x)
  VZero -> Zero
  VSucc s -> Succ (quoteSize l s)

quoteTm :: Lvl -> VTm -> Tm
quoteTm l = \case
  VVar x -> Var (lvl2Ix l x)
  VApp t u -> App (quoteTm l t) (quoteTm l u)
  VLam x t -> Lam x (quoteTm (l + 1) (t (VVar l)))
  VLAbs x t -> LAbs x (quoteTm (l + 1) (t (VLVar l)))
  VLApp t s -> LApp (quoteTm l t) (quoteSize l s)

  -- Coding
  VCode i a -> Code (quoteSize l i) (quoteTp l a)

quoteTp :: Lvl -> VTp -> Tp
quoteTp l = \case
  VPi  x a b -> Pi x (quoteTp l a) (quoteTp (l + 1) (b (VVar l)))
  VU i -> U (quoteSize l i)
  VLPi x t -> LPi x (quoteTp (l + 1) (t (VLVar l)))

  -- Decoding
  VDecode i t -> Decode (quoteSize l i) (quoteTm l t)

nf :: Env -> Tm -> Tm
nf env t = quoteTm (Lvl (length env)) (evalTm env t)

convTm :: Lvl -> VTm -> VTm -> Bool
convTm l t u = case (t, u) of
  (VLam _ t, VLam _ t') ->
    convTm (l + 1) (t (VVar l)) (t' (VVar l))

  (VLam _ t, u) ->
    convTm (l + 1) (t (VVar l)) (VApp u (VVar l))
  (u, VLam _ t) ->
    convTm (l + 1) (VApp u (VVar l)) (t (VVar l))

  (VVar x  , VVar x'   ) -> x == x'
  (VApp t u, VApp t' u') -> convTm l t t' && convTm l u u'
  
  (VLAbs _ t, VLAbs _ t') -> convTm (l + 1) (t (VLVar l)) (t' (VLVar l))
  (VLApp t s, VLApp t' s') -> convTm l t t' && s == s'

  (VCode i a, VCode j b) | i == j -> convTp l a b

  _ -> False

convTp :: Lvl -> VTp -> VTp -> Bool
convTp l t u = case (t, u) of
  (VU i, VU i') -> i == i'

  (VPi _ a b, VPi _ a' b') ->
       convTp l a a'
    && convTp (l + 1) (b (VVar l)) (b' (VVar l))
    
  (VLPi _ a, VLPi _ a') -> convTp (l + 1) (a (VLVar l)) (a' (VLVar l))

  (VDecode i a, VDecode j b) | i == j -> convTm l a b

  _ -> False


-- Elaboration
--------------------------------------------------------------------------------

-- type of every variable in scope
type Tppes = [(Name, VTp)]

-- Elaboration context
data Cxt = Cxt {env :: Env, types :: Tppes, lvl :: Lvl, pos :: SourcePos}

emptyCxt :: SourcePos -> Cxt
emptyCxt = Cxt [] [] 0

-- Extend Cxt with a bound term variable
bind :: Name -> VTp -> Cxt -> Cxt
bind x ~a (Cxt env types l pos) =
  Cxt (VETm (VVar l):env) ((x, a):types) (l + 1) pos

-- Extend Cxt with a bound level variable
bindLevel :: Name -> Cxt -> Cxt
bindLevel x (Cxt env types l pos) =
  Cxt (VESize (VLVar l):env) ((x, VU VZero):types) (l + 1) pos
  
-- Extend Cxt with a definition
define :: Name -> VTm -> VTp -> Cxt -> Cxt
define x ~t ~a (Cxt env types l pos) =
  Cxt (VETm t:env) ((x, a):types) (l + 1) pos

-- Tppechecking monad
type M = Either (String, SourcePos)


-- Printing and error reporting
report :: Cxt -> String -> M a
report cxt msg = Left (msg, pos cxt)

deriving instance Show Tm
deriving instance Show Tp

showTm :: Cxt -> Tm -> String
showTm cxt t = prettyTm 0 (map fst (types cxt)) t []

showTp :: Cxt -> Tp -> String
showTp cxt a = prettyTp 0 (map fst (types cxt)) a []

showTm0 :: Tm -> String
showTm0 t = prettyTm 0 [] t []

showTp0 :: Tp -> String
showTp0 a = prettyTp 0 [] a []

showVal :: Cxt -> VTm -> String
showVal cxt v = showTm cxt $ quoteTm (lvl cxt) v

showVTp :: Cxt -> VTp -> String
showVTp cxt v = showTp cxt $ quoteTp (lvl cxt) v

showSize :: Cxt -> VSize -> String
showSize cxt s = prettySize (map fst (types cxt)) (quoteSize (lvl cxt) s) ""

--------------------------------------------------------------------------------

vApp :: VTm -> VTm -> VTm
vApp (VLam _ f) v = f v
vApp f          v = VApp f v

coe :: Cxt -> Lvl -> VTp -> VTp -> Tm -> M Tm
coe cxt l sourceTp targetTp m = case (sourceTp, targetTp) of
  (VU i, VU j) | i <= j -> 
    pure $ Code (quoteSize (lvl cxt) j) (Decode (quoteSize (lvl cxt) i) m)

  (VPi n1 a1 b1, VPi n2 a2 b2) -> do
    let cxt' = bind n2 a2 cxt
    let l' = lvl cxt'
    
    u_x <- coe cxt' l' a2 a1 (Var (Ix 0))

    let vu_x = evalTm (env cxt') u_x
    let vm = evalTm (env cxt) m
    let m_u_x = quoteTm l' (vApp vm vu_x)
    
    n_x <- coe cxt' l' (b1 vu_x) (b2 (VVar l)) m_u_x
    
    pure $ Lam n2 n_x

  _ -> 
    if convTp l sourceTp targetTp then pure m 
    else report cxt "Error: Invalid coercion"

elabSize :: Cxt -> RawSize -> M Size
elabSize cxt = \case
  RSzVar x -> do
    let go i [] = report cxt ("Level variable out of scope: " ++ x)
        go i ((x', _):tys)
          | x == x'   = case env cxt !! i of
            VESize _ -> pure (LVar (Ix i))
            VETm _ -> report cxt ("Expected a level variable, but '" ++ x ++ "' is a term variable.")
          | otherwise = go (i + 1) tys
    go 0 (types cxt)
  RSz i -> pure (iterate Succ Zero !! i)
  RSucc s -> Succ <$> elabSize cxt s
  
checkTp :: Cxt -> Raw -> Maybe VSize -> M Tp
checkTp cxt t size = case t of

  RSrcPos pos t -> checkTp (cxt {pos = pos}) t size

  RU s -> do
    s <- elabSize cxt s
    case size of
      Nothing -> pure $ U s
      Just sz -> do
        let vs = evalSize (env cxt) s 
        if vs < sz
        then pure $ U s
        else report cxt ("Size issue: U " ++ showSize cxt vs ++ " is too large to fit in " ++ showSize cxt sz)

  RPi x a b -> do
    a' <- checkTp cxt a size
    let cxt' = bind x (evalTp (env cxt) a') cxt
    b' <- checkTp cxt' b size
    pure $ Pi x a' b'
    
  RLPi l a -> do
    let cxt' = bindLevel l cxt
    a' <- checkTp cxt' a size
    pure $ LPi l a'

  -- mode switch
  _ -> do
    (t, a) <- infer cxt t
    case a of
      VU i -> case size of 
        Nothing -> pure (Decode (quoteSize (lvl cxt) i) t)
        Just sz -> do
          if i <= sz then
            pure (Decode (quoteSize (lvl cxt) i) t)
          else 
            report cxt ("Size issue: got a code at level " ++ showSize cxt i ++ ", but expected at most " ++ showSize cxt sz)
      _    -> report cxt "Elaboration error: Expected a code"

check :: Cxt -> Raw -> VTp -> M Tm
check cxt t a = case (t, a) of
  (RSrcPos pos t, a) -> check (cxt {pos = pos}) t a

  (RLam x t, VPi x' a b) ->
    Lam x <$> check (bind x a cxt) t (b (VVar (lvl cxt)))

  (RLAbs l t, VLPi _ b) -> do
    let cxt' = bindLevel l cxt
    t' <- check cxt' t (b (VLVar (lvl cxt)))
    pure $ LAbs l t'

  (_, VU i) -> do
    u <- checkTp cxt t (Just i)
    pure $ Code (quoteSize (lvl cxt) i) u

  (RLet x a t u, a') -> do
    a <- checkTp cxt a Nothing
    let ~va = evalTp (env cxt) a
    t <- check cxt t va
    let ~vt = evalTm (env cxt) t
    u <- check (define x vt va cxt) u a' 
    pure (Let x a t u)

  -- mode switch
  _ -> do
    (m, bTp) <- infer cxt t
    coe cxt (lvl cxt) bTp a m
    
infer :: Cxt -> Raw -> M (Tm, VTp)
infer cxt = \case
  RSrcPos pos t -> infer (cxt {pos = pos}) t

  RVar x -> do
    let go i [] = report cxt ("variable out of scope: " ++ x)
        go i ((x', a):tys)
          | x == x'   = case env cxt !! i of
            VETm _ -> pure (Var (Ix i), a)
            VESize _ -> report cxt ("Expected a term variable, but '" ++ x ++ "' is a level variable.")
          | otherwise = go (i + 1) tys
    go 0 (types cxt)

  RApp t u -> do
    (t', tty) <- infer cxt t
    case tty of
      VPi _ a b -> do
        u' <- check cxt u a
        pure (App t' u', b (evalTm (env cxt) u'))
      tty ->
        report cxt $ "Expected a function type, instead inferred:\n\n  " ++ showVTp cxt tty

  RLApp t s -> do
    (tTm, tTp) <- infer cxt t
    case tTp of
      VLPi _ b -> do
        sz <- elabSize cxt s
        let vsz = evalSize (env cxt) sz
        pure (LApp tTm sz, b vsz)
      _ -> report cxt ("Expected a level-polymorphic type for level application, instead inferred:\n\n  " ++ showVTp cxt tTp)

  RLet x a t u -> do
    a <- checkTp cxt a Nothing
    let ~va = evalTp (env cxt) a
    t <- check cxt t va
    let ~vt = evalTm (env cxt) t
    (u, uty) <- infer (define x vt va cxt) u  
    pure (Let x a t u, uty)


  RU {} -> report cxt "Can't infer type for universe"
  RPi {} -> report cxt "Can't infer type for product type"
  RLam {} -> report cxt "Can't infer type for lambda expression."
  RLPi {} -> report cxt "Can't infer type for level product type"
  RLAbs {} -> report cxt "Can't infer type for level abstraction"


-- printing
--------------------------------------------------------------------------------

fresh :: [Name] -> Name -> Name
fresh ns "_" = "_"
fresh ns x | elem x ns = go (1 :: Int) where
  go n | elem (x ++ show n) ns = go (n + 1)
       | otherwise             = x ++ show n
fresh ns x = x

atomp = 3  :: Int 
appp  = 2  :: Int 
pip   = 1  :: Int 
letp  = 0  :: Int 

par :: Int -> Int -> ShowS -> ShowS
par p p' = showParen (p' < p)

prettySize :: [Name] -> Size -> ShowS
prettySize ns = \case
  LVar (Ix x) -> 
    if x < 0 || x >= length ns then 
      (("l" ++ show x) ++)
    else 
      ((ns !! x) ++)
  Zero -> ("0" ++)
  Succ s -> prettySize ns s . (" + 1"++)

prettyTm :: Int -> [Name] -> Tm -> ShowS
prettyTm = goTm where

  goTm :: Int -> [Name] -> Tm -> ShowS
  goTm p ns = \case
    Var (Ix x) ->
      if x < 0 || x >= length ns then 
        (("Free" ++ show x) ++)
      else case ns !! x of
        "_"   -> ("@"++).(show x++)
        n     -> (n++)

    App t u                   -> par p appp $ goTm appp ns t . (' ':) . goTm atomp ns u

    Lam (fresh ns -> x) t     -> par p letp $ ("λ "++) . (x++) . goLam (x:ns) t where
                                   goLam ns (Lam (fresh ns -> x) t) =
                                     (' ':) . (x++) . goLam (x:ns) t
                                   goLam ns t =
                                     (". "++) . goTm letp ns t

    LAbs (fresh ns -> x) t    -> par p letp $ ("Λ "++) . (x++) . goLAbs (x:ns) t where
                                   goLAbs ns (LAbs (fresh ns -> x) t') =
                                     (' ':) . (x++) . goLAbs (x:ns) t'
                                   goLAbs ns t' =
                                     (". "++) . goTm letp ns t'

    LApp t s                  -> par p appp $ goTm appp ns t . (" {"++) . prettySize ns s . ("}"++)

    Code i t -> ('[':).prettyTp letp ns t.(']':)

    Let (fresh ns -> x) a t u ->
      par p letp $ ("let "++) . (x++) . (" : "++) . prettyTp letp ns a
      . ("\n    = "++) . goTm letp ns t . ("\n;\n"++) . goTm letp (x:ns) u

prettyTp :: Int -> [Name] -> Tp -> ShowS
prettyTp = goTp where
  piBind ns x a =
    showParen True ((x++) . (" : "++) . goTp letp ns a)

  goTp :: Int -> [Name] -> Tp -> ShowS
  goTp p ns = \case    
    U i                       -> par p appp $ ("U "++).prettySize ns i

    Pi "_" a b                -> par p pip $ goTp appp ns a . (" → "++) . goTp pip ("_":ns) b

    Pi (fresh ns -> x) a b    -> par p pip $ piBind ns x a . goPi (x:ns) b where
                                   goPi ns (Pi "_" a b) = (" → "++) . goTp appp ns a
                                                          . (" → "++) . goTp pip ("_":ns) b
                                   goPi ns (Pi x a b)   = piBind ns x a . goPi (x:ns) b
                                   goPi ns b            = (" → "++) . goTp pip ns b

    LPi (fresh ns -> x) t     -> par p pip $ ("∀ "++) . (x++) . goLPi (x:ns) t where
                                   goLPi ns (LPi (fresh ns -> x) t') =
                                     (' ':) . (x++) . goLPi (x:ns) t'
                                   goLPi ns t' =
                                     (". "++) . goTp pip ns t'

    Decode i t   -> ('<':).prettyTm letp ns t.('>':)


-- parsing
--------------------------------------------------------------------------------

type Parser = Parsec Void String

ws :: Parser ()
ws = L.space C.space1 (L.skipLineComment "--") (L.skipBlockComment "{-" "-}")

withPos :: Parser Raw -> Parser Raw
withPos p = RSrcPos <$> getSourcePos <*> p

lexeme   = L.lexeme ws
symbol s = lexeme (C.string s)
char c   = lexeme (C.char c)
parens p = char '(' *> p <* char ')'
pArrow   = symbol "→" <|> symbol "->"
decimal  = lexeme L.decimal

keyword :: String -> Bool
keyword x = x `elem` ["let", "λ", "U", "forall"]

pIdent :: Parser Name
pIdent = try $ do
  x <- takeWhile1P Nothing isAlphaNum
  guard (not (keyword x))
  x <$ ws

pKeyword :: String -> Parser ()
pKeyword kw = do
  C.string kw
  (takeWhile1P Nothing isAlphaNum *> empty) <|> ws

pRawSizeAtom :: Parser RawSize
pRawSizeAtom = 
      (RSz <$> decimal)
  <|> (RSzVar <$> pIdent)
  <|> parens pRawSize

pRawSize :: Parser RawSize
pRawSize = do
  base <- pRawSizeAtom
  pluses <- many (symbol "+" *> decimal)
  pure $ foldl (\s n -> iterate RSucc s !! n) base pluses

pAtom :: Parser Raw
pAtom =
      withPos (
            (RVar <$> pIdent)
        <|> (RU <$> (pKeyword "U" *> pRawSize))
      )
  <|> parens pRaw

pBinder = pIdent <|> symbol "_"


pSpine :: Parser Raw
pSpine = do
  head <- pAtom
  args <- many (
          (Right <$> try (symbol "{" *> pRawSize <* symbol "}"))
      <|> (Left <$> pAtom)
    )
  pure $ foldl (\t arg -> case arg of Left u -> RApp t u; Right s -> RLApp t s) head args

pLam = do
  char 'λ' <|> char '\\'
  xs <- some pBinder
  char '.'
  t <- pRaw
  pure (foldr RLam t xs)

pPi = do
  dom <- some (parens ((,) <$> some pBinder <*> (char ':' *> pRaw)))
  pArrow
  cod <- pRaw
  pure $ foldr (\(xs, a) t -> foldr (\x -> RPi x a) t xs) cod dom

pLPi = do
  symbol "∀" <|> symbol "forall"
  l <- pBinder
  symbol "."
  t <- pRaw
  pure (RLPi l t)

pLLam = do
  symbol "Λ" <|> symbol "/\\"
  l <- pBinder
  symbol "."
  t <- pRaw
  pure (RLAbs l t)

funOrSpine = do
  sp <- pSpine
  optional pArrow >>= \case
    Nothing -> pure sp
    Just _  -> RPi "_" sp <$> pRaw

pLet = do
  pKeyword "let"
  x <- pBinder
  symbol ":"
  a <- pRaw
  symbol "="
  t <- pRaw
  char ';'
  u <- pRaw
  pure $ RLet x a t u

pRaw = withPos (pLPi <|> pLLam <|> pLam <|> pLet <|> try pPi <|> funOrSpine)
pSrc = ws *> pRaw <* eof

parseString :: String -> IO Raw
parseString src =
  case parse pSrc "(stdin)" src of
    Left e -> do
      putStrLn $ errorBundlePretty e
      exitSuccess
    Right t ->
      pure t

parseStdin :: IO (Raw, String)
parseStdin = do
  file <- getContents
  tm   <- parseString file
  pure (tm, file)

-- main
--------------------------------------------------------------------------------

displayError :: String -> (String, SourcePos) -> IO ()
displayError file (msg, SourcePos path (unPos -> linum) (unPos -> colnum)) = do
  let lnum = show linum
      lpad = map (const ' ') lnum
  printf "%s:%d:%d:\n" path linum colnum
  printf "%s |\n"    lpad
  printf "%s | %s\n" lnum (lines file !! (linum - 1))
  printf "%s | %s\n" lpad (replicate (colnum - 1) ' ' ++ "^")
  printf "%s\n" msg

helpMsg = unlines [
  "usage: elabzoo-univ-lifts [--help|nf|type]",
  "  --help         : display this message",
  "  nf             : read & elaborate expression from stdin, print its normal form and type",
  "  elab           : read & elaborate expression from stdin, print output",
  "  elab-no-delift : read & elaborate expression from stdin, print output",
  "                   without removing intermediate lifts and explicit weakenings",
  "  type           : read & elaborate expression from stdin, print its type"]

mainWith :: IO [String] -> IO (Raw, String) -> IO ()
mainWith getOpt getRaw = do
  getOpt >>= \case
    ["--help"] -> putStrLn helpMsg
    ["nf"]   -> do
      (t, file) <- getRaw
      case infer (emptyCxt (initialPos file)) t of
        Left err -> displayError file err
        Right (t, a) -> do
          putStrLn $ showTm0 $ nf [] t
          putStrLn "  :"
          putStrLn $ showTp0 $ quoteTp 0 a
    ["elab"] -> do
      (t, file) <- getRaw
      case infer (emptyCxt (initialPos file)) t of
        Left err     -> displayError file err
        Right (t, a) -> putStrLn $ showTm0 $ t
    ["type"] -> do
      (t, file) <- getRaw
      case infer (emptyCxt (initialPos file)) t of
        Left err     -> displayError file err
        Right (t, a) -> putStrLn $ showTp0 $ quoteTp 0 a
    _ -> putStrLn helpMsg

main :: IO ()
main = ex0

main' :: String -> String -> IO ()
main' mode src = mainWith (pure [mode]) ((,src) <$> parseString src)